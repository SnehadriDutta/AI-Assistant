from langchain_groq import ChatGroq
from config import GROQ_API_KEY, MODEL_NAME
from schemas import IntentResult, SlotExtractionResult, GuardrailResult

_base_llm = ChatGroq(model=MODEL_NAME, api_key=GROQ_API_KEY)

# Structured output variants
intent_llm    = _base_llm.with_structured_output(IntentResult)
slot_llm      = _base_llm.with_structured_output(SlotExtractionResult)
guardrail_llm = _base_llm.with_structured_output(GuardrailResult)

# Plain chat LLM (for respond_node)
chat_llm = _base_llm
