from langchain_core.tools import tool


@tool
def get_prices(symbol: str) -> dict:
    """Get current stock price for a symbol."""
    # Replace with real API call (e.g. Alpha Vantage, Yahoo Finance)
    return {"symbol": symbol, "price": 142.5, "change_pct": 1.2}


@tool
def get_news(symbol: str) -> list:
    """Get latest news headlines for a stock symbol."""
    # Replace with real API call (e.g. Finnhub, NewsAPI)
    return [
        {"headline": f"Analysts upgrade {symbol} target", "source": "Reuters"},
        {"headline": f"{symbol} Q3 earnings beat estimates",   "source": "Bloomberg"},
    ]


@tool
def get_portfolio(user_id: str) -> dict:
    """Get user's current portfolio holdings."""
    # Replace with real DB / brokerage API call
    return {
        "user_id":  user_id,
        "holdings": [
            {"symbol": "AAPL", "units": 10, "avg_cost": 135.0},
            {"symbol": "TSLA", "units":  5, "avg_cost": 210.0},
        ],
    }


@tool
def get_historical(symbol: str, period: str = "1mo") -> dict:
    """Get historical OHLCV data for a symbol."""
    # Replace with real API call
    return {
        "symbol": symbol,
        "period": period,
        "data":   [{"date": "2024-01-01", "close": 140.0}],
    }


# Registry — add new tools here; the rest of the system picks them up automatically
ALL_TOOLS = [get_prices, get_news, get_portfolio, get_historical]
TOOL_MAP: dict[str, any] = {t.name: t for t in ALL_TOOLS}
