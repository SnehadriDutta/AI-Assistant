import asyncio
import logging
from typing import Any

from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    RetryError,
)

from schemas import AppState, ToolCallPlan, ToolResult
from tools.registry import TOOL_MAP
from config import TOOL_MAX_RETRIES, TOOL_RETRY_MIN_WAIT, TOOL_RETRY_MAX_WAIT

logger = logging.getLogger(__name__)

# Errors considered transient (worth retrying)
TRANSIENT_ERRORS = (TimeoutError, ConnectionError, OSError)

# Maps exception types to user-friendly strings
_ERROR_MAP: list[tuple[type, str]] = [
    (TimeoutError,    "service timed out"),
    (ConnectionError, "service unavailable"),
    (KeyError,        "unexpected data format"),
    (ValueError,      "invalid input"),
]


def _friendly_error(tool_name: str, exc: Exception) -> str:
    reason = next(
        (msg for cls, msg in _ERROR_MAP if isinstance(exc, cls)),
        "unexpected error",
    )
    return f"{tool_name}: {reason}"


def resolve_args(
    tool_fn,
    state: AppState,
    upstream_results: dict[str, ToolResult] | None = None,
) -> dict:
    """
    Build kwargs for a tool call by merging (in priority order):
      1. state slots
      2. user_id from state
      3. flattened data from upstream tool results (enables chaining)
    Only keys present in the tool's schema are included.
    """
    upstream_results = upstream_results or {}
    schema     = tool_fn.args_schema.model_json_schema()
    properties = schema.get("properties", {})

    upstream_data: dict[str, Any] = {}
    for result in upstream_results.values():
        if result["status"] == "ok" and isinstance(result["data"], dict):
            upstream_data.update(result["data"])
        # also expose holdings list under "holdings" key if present
        if result["status"] == "ok" and isinstance(result.get("data"), dict):
            if "holdings" in result["data"]:
                upstream_data["holdings"] = result["data"]["holdings"]

    available = {
        **upstream_data,
        **state.get("slots", {}),
        "user_id": state.get("user_id"),
    }

    missing = [k for k in properties if k not in available]
    if missing:
        logger.warning(f"Tool {tool_fn.name}: missing args {missing}")

    return {k: available[k] for k in properties if k in available}


async def _invoke_tool(
    plan: ToolCallPlan,
    state: AppState,
    upstream_results: dict[str, ToolResult],
) -> tuple[str, ToolResult]:
    """Invoke a single tool with optional retry, returning (name, ToolResult)."""
    fn   = TOOL_MAP.get(plan["name"])
    if fn is None:
        return plan["name"], {
            "status": "failed",
            "data":   None,
            "error":  f"{plan['name']}: tool not registered",
        }

    args = resolve_args(fn, state, upstream_results)

    async def _call():
        # langchain tools are synchronous — run in thread pool
        return await asyncio.get_event_loop().run_in_executor(None, fn.invoke, args)

    try:
        if plan.get("retryable", True):
            retrying = retry(
                stop=stop_after_attempt(TOOL_MAX_RETRIES),
                wait=wait_exponential(
                    multiplier=1,
                    min=TOOL_RETRY_MIN_WAIT,
                    max=TOOL_RETRY_MAX_WAIT,
                ),
                retry=retry_if_exception_type(TRANSIENT_ERRORS),
            )(_call)
            data = await retrying()
        else:
            data = await _call()

        logger.info(f"Tool {plan['name']} succeeded")
        return plan["name"], {"status": "ok", "data": data, "error": None}

    except (RetryError, Exception) as exc:
        base = exc.__cause__ if isinstance(exc, RetryError) else exc
        logger.warning(f"Tool {plan['name']} failed: {base}")
        return plan["name"], {
            "status": "failed",
            "data":   None,
            "error":  _friendly_error(plan["name"], base),
        }


async def run_tool_dag(
    plan: list[ToolCallPlan],
    state: AppState,
) -> dict[str, ToolResult]:
    """
    Execute tools respecting declared dependencies.

    Each 'wave' contains all tools whose depends_on are fully resolved.
    Tools within a wave run in parallel via asyncio.gather.
    If a critical tool fails, all remaining tools are cancelled immediately.
    If a non-critical tool fails, its dependents are cancelled but execution continues.
    """
    results:   dict[str, ToolResult] = {}
    failed:    set[str]              = set()
    remaining: dict[str, ToolCallPlan] = {t["name"]: t for t in plan}

    while remaining:
        # Build next wave: all tools whose dependencies are complete
        wave = [
            t for t in remaining.values()
            if all(dep in results for dep in t.get("depends_on", []))
            and not any(dep in failed for dep in t.get("depends_on", []))
        ]

        # Cancel tools whose upstream failed
        newly_cancelled = [
            t for t in remaining.values()
            if any(dep in failed for dep in t.get("depends_on", []))
            and t["name"] not in [w["name"] for w in wave]
        ]
        for tc in newly_cancelled:
            failed_dep = next(d for d in tc["depends_on"] if d in failed)
            results[tc["name"]] = {
                "status": "cancelled",
                "data":   None,
                "error":  f"skipped — upstream '{failed_dep}' failed",
            }
            del remaining[tc["name"]]

        if not wave:
            if remaining:
                logger.error(f"Unresolvable dependency or all paths cancelled: {list(remaining)}")
                for name in list(remaining):
                    results[name] = {
                        "status": "cancelled",
                        "data":   None,
                        "error":  "unresolvable dependency",
                    }
            break

        wave_results = await asyncio.gather(
            *[_invoke_tool(tc, state, results) for tc in wave]
        )

        abort = False
        for name, result in wave_results:
            results[name] = result
            del remaining[name]
            if result["status"] == "failed":
                failed.add(name)
                tc = next(t for t in plan if t["name"] == name)
                if tc.get("critical", True):
                    logger.error(f"Critical tool {name} failed — aborting DAG")
                    # Cancel everything still pending
                    for r in list(remaining):
                        results[r] = {
                            "status": "cancelled",
                            "data":   None,
                            "error":  f"skipped — critical tool '{name}' failed",
                        }
                    remaining.clear()
                    abort = True
                    break
        if abort:
            break

    return results
