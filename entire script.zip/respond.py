import logging
from tenacity import RetryError

from schemas import AppState
from llm_client import chat_llm
from utils.helpers import with_llm_retry
from config import INTENT_SLOTS

logger = logging.getLogger(__name__)

_BASE_SYSTEM = (
    "You are a financial assistant on a trading platform. "
    "Answer concisely and accurately. "
    "Never simulate, execute, or fabricate order results, prices, or portfolio data. "
    "Only use the data explicitly provided to you."
)


def _build_system_prompt(state: AppState) -> str:
    parts   = [_BASE_SYSTEM]
    results = state.get("tool_results", {})

    ok      = {k: v["data"]  for k, v in results.items() if v["status"] == "ok"}
    failed  = {k: v["error"] for k, v in results.items() if v["status"] == "failed"}
    skipped = {k: v["error"] for k, v in results.items() if v["status"] == "cancelled"}

    if ok:
        parts.append(f"\nData fetched for this request:\n{ok}")

    if failed or skipped:
        parts.append(
            "\nSome data could not be retrieved. "
            "Answer using ONLY the data above. "
            "Explicitly tell the user which part of their question you cannot answer and why.\n"
            f"Failed: {failed}\nSkipped: {skipped}"
        )

    if not ok and (failed or skipped):
        parts.append(
            "\nAll data fetching failed. "
            "Tell the user clearly what went wrong and suggest they try again. "
            "Do NOT speculate or invent data."
        )

    # Action intent confirmation
    if state["intent"] in INTENT_SLOTS and state.get("awaiting_confirm"):
        action = {
            "place_order":   "order ticket is being opened",
            "add_watchlist": "symbol is being added to your watchlist",
        }.get(state["intent"], "action is being processed")
        parts.append(
            f"\nAll required details have been collected: {state['slots']}. "
            f"Inform the user their {action}."
        )

    return "\n".join(parts)


def _fallback_response(state: AppState) -> str:
    """
    Template a response directly from tool_results when the LLM is unavailable.
    Covers the most common query types — extend as you add tools.
    """
    results = state.get("tool_results", {})
    lines: list[str] = []

    if "get_prices" in results and results["get_prices"]["status"] == "ok":
        d = results["get_prices"]["data"]
        lines.append(
            f"{d.get('symbol', '?')} is currently trading at {d.get('price', '?')} "
            f"({d.get('change_pct', '?'):+}%)."
        )

    if "get_portfolio" in results and results["get_portfolio"]["status"] == "ok":
        holdings = results["get_portfolio"]["data"].get("holdings", [])
        summary  = ", ".join(f"{h['units']}× {h['symbol']}" for h in holdings)
        lines.append(f"Your portfolio: {summary}.")

    if "get_news" in results and results["get_news"]["status"] == "ok":
        headlines = [n["headline"] for n in results["get_news"]["data"][:2]]
        lines.append("Recent news: " + " | ".join(headlines))

    if "get_historical" in results and results["get_historical"]["status"] == "ok":
        d = results["get_historical"]["data"]
        lines.append(f"Historical data for {d.get('symbol', '?')} ({d.get('period', '?')}) retrieved.")

    if not lines:
        return (
            "I retrieved your data but am unable to format a response right now. "
            "Please try again shortly."
        )

    lines.append("\n⚠️  Response generated from raw data — AI formatting is temporarily unavailable.")
    return "\n".join(lines)


def respond_node(state: AppState) -> AppState:
    system = _build_system_prompt(state)

    # Keep last 20 messages to avoid hitting context limits
    trimmed_messages = state["messages"][-20:]

    try:
        response = with_llm_retry(
            chat_llm.invoke,
            [{"role": "system", "content": system}, *trimmed_messages],
        )
        content = response.content

    except RetryError as exc:
        logger.error(f"Respond LLM failed after retries: {exc}")
        content = _fallback_response(state)

    return {
        **state,
        "awaiting_confirm": False,
        "tool_results":     {},
        "messages": state["messages"] + [{"role": "assistant", "content": content}],
    }
