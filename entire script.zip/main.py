import logging
from graph.builder import app
from schemas import AppState

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)


def make_initial_state(user_id: str) -> AppState:
    return {
        "messages":          [],
        "intent":            None,
        "slots":             {},
        "awaiting_confirm":  False,
        "tool_plan":         [],
        "tool_results":      {},
        "user_id":           user_id,
        "guardrail_verdict": None,
    }


def run():
    state = make_initial_state(user_id="user_123")
    print("Trading Assistant  (type 'exit' to quit)\n")

    while True:
        user_input = input("You: ").strip()
        if not user_input:
            continue
        if user_input.lower() == "exit":
            break

        state = {
            **state,
            "messages": state["messages"] + [{"role": "user", "content": user_input}],
        }

        state = app.invoke(state)

        last = next(
            (m for m in reversed(state["messages"]) if m["role"] == "assistant"),
            None,
        )
        if last:
            print(f"\nBot: {last['content']}\n")


if __name__ == "__main__":
    run()
