from langgraph.graph import END

from schemas import AppState
from config  import INTENT_SLOTS


def route_after_guardrail(state: AppState) -> str:
    """
    Pass → proceed to entry router.
    Any block verdict → reject immediately.
    """
    verdict = state.get("guardrail_verdict", "unsafe")
    return "entry_router" if verdict == "pass" else "reject"


def entry_router(state: AppState) -> str:
    """
    Skip intent detection when we already have an active intent
    (i.e. user is answering a slot question mid-flow).
    """
    if state.get("intent") and state["intent"] != "__llm_error__":
        return "collect"
    return "intent"


def route_after_intent(state: AppState) -> str:
    """
    LLM error    → END (error message already appended by intent_node)
    Action intent → collect (slot filling required)
    Has tool plan → tool
    Otherwise     → respond (general query, no tools needed)
    """
    intent = state.get("intent")

    if intent == "__llm_error__":
        return END

    if intent in INTENT_SLOTS:
        return "collect"

    if state.get("tool_plan"):
        return "tool"

    return "respond"


def route_after_collect(state: AppState) -> str:
    """
    Slots complete → respond.
    Still missing  → END (collect_node has already appended the ask message).
    LLM error mid-collect → END (error message already appended).
    """
    # LLM error: intent is still set but no awaiting_confirm and last message is from assistant
    last = state["messages"][-1] if state["messages"] else {}
    if last.get("role") == "assistant" and not state.get("awaiting_confirm"):
        return END

    if state.get("awaiting_confirm"):
        return "respond"

    return END


def route_after_respond(state: AppState) -> str:
    """
    Action intents need a reset so the next turn starts fresh.
    Query/general intents are stateless — go straight to END.
    """
    if state.get("intent") in INTENT_SLOTS:
        return "reset"
    return END
