import asyncio
import logging

from schemas import AppState
from tools.executor import run_tool_dag

logger = logging.getLogger(__name__)


def tool_node(state: AppState) -> AppState:
    """
    Synchronous wrapper around the async DAG executor.
    Runs all tools in state['tool_plan'] respecting dependencies.
    """
    plan = state.get("tool_plan", [])
    if not plan:
        logger.info("Tool node: no tools in plan, skipping")
        return state

    try:
        results = asyncio.run(run_tool_dag(plan, state))
    except Exception as exc:
        # Executor itself crashed (not a tool failure) — mark everything failed
        logger.error(f"DAG executor crashed: {exc}")
        results = {
            t["name"]: {"status": "failed", "data": None, "error": "executor error"}
            for t in plan
        }

    for name, r in results.items():
        logger.info(f"Tool result: {name} → status={r['status']} error={r.get('error')}")

    return {**state, "tool_results": results}
