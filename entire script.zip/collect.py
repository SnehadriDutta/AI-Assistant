import logging
from typing import cast
from tenacity import RetryError

from schemas import AppState, SlotExtractionResult
from llm_client import slot_llm
from utils.helpers import with_llm_retry, normalise_slots, get_missing_slots, LLM_ERROR_RESPONSE

logger = logging.getLogger(__name__)


def collect_node(state: AppState) -> AppState:
    user_msg = state["messages"][-1]["content"]
    intent   = state["intent"]
    slots    = state["slots"]

    system = (
        f"Extract slot values from the user message for intent: '{intent}'.\n"
        f"Known slots so far: {slots}.\n"
        "Only return fields explicitly mentioned in the message.\n"
        "Valid slot names: symbol, units, order_type, price, sl, tp.\n"
        "Always use lowercase for string values (e.g. order_type: 'limit')."
    )

    try:
        result = cast(
            SlotExtractionResult,
            with_llm_retry(
                slot_llm.invoke,
                [
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user_msg},
                ],
            ),
        )
        new_slots = normalise_slots(result.slots)
    except RetryError as exc:
        logger.error(f"Slot LLM failed after retries: {exc}")
        # Keep existing slots; ask the user to repeat
        return {
            **state,
            "awaiting_confirm": False,
            "messages": state["messages"] + [
                {"role": "assistant", "content": LLM_ERROR_RESPONSE}
            ],
        }

    merged  = normalise_slots({**slots, **new_slots})
    missing = get_missing_slots(intent, merged)

    logger.info(f"Collect: merged_slots={merged} missing={missing}")

    if missing:
        ask = f"Please provide the following details: {', '.join(missing)}"
        return {
            **state,
            "slots":            merged,
            "awaiting_confirm": False,
            "messages": state["messages"] + [{"role": "assistant", "content": ask}],
        }

    return {**state, "slots": merged, "awaiting_confirm": True}
