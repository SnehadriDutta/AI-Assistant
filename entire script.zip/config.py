from typing import Literal

GROQ_API_KEY = "YOUR_GROQ_API_KEY"
MODEL_NAME   = "llama-3.3-70b-versatile"

# Slot definitions per intent
INTENT_SLOTS: dict[str, list[str]] = {
    "place_order":   ["symbol", "units", "order_type"],
    "add_watchlist": ["symbol"],
}

# Conditional slots: once a slot has a known value, additional slots may be required
CONDITIONAL_SLOTS: dict[str, dict[str, dict[str, list[str]]]] = {
    "place_order": {
        "order_type": {
            "limit":  ["price"],
            "stop":   ["price", "sl"],
            "market": [],
        }
    }
}

DOMAIN_DESCRIPTION = """
In scope: stock prices, portfolio queries, placing/managing orders,
watchlists, market news, financial instruments, trade history.
Out of scope: general knowledge, personal lifestyle advice, anything
unrelated to financial markets or trading.
"""

# Fixed rejection strings — never LLM-generated
REJECT_MESSAGES: dict[str, str] = {
    "off_domain": (
        "I'm a trading assistant and can only help with markets, "
        "portfolios, orders, and financial data."
    ),
    "unsafe": "I can't help with that.",
}

# Retry config for LLM calls
LLM_MAX_RETRIES  = 2
LLM_RETRY_MIN_WAIT = 1   # seconds
LLM_RETRY_MAX_WAIT = 6

# Retry config for tool calls
TOOL_MAX_RETRIES = 2
TOOL_RETRY_MIN_WAIT = 1
TOOL_RETRY_MAX_WAIT = 8
