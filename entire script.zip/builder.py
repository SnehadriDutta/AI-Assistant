from langgraph.graph import StateGraph, END

from schemas import AppState
from nodes   import (
    guardrail_node,
    reject_node,
    intent_node,
    collect_node,
    tool_node,
    respond_node,
    reset_node,
)
from graph.routers import (
    route_after_guardrail,
    entry_router,
    route_after_intent,
    route_after_collect,
    route_after_respond,
)


def build_graph() -> StateGraph:
    g = StateGraph(AppState)

    # ── Nodes ──────────────────────────────────────────────────────────────────
    g.add_node("guardrail",   guardrail_node)
    g.add_node("reject",      reject_node)
    g.add_node("entry_router", lambda s: s)   # passthrough — routing only
    g.add_node("intent",      intent_node)
    g.add_node("collect",     collect_node)
    g.add_node("tool",        tool_node)
    g.add_node("respond",     respond_node)
    g.add_node("reset",       reset_node)

    # ── Entry ──────────────────────────────────────────────────────────────────
    g.set_entry_point("guardrail")

    # ── Edges ──────────────────────────────────────────────────────────────────

    # guardrail → reject | entry_router
    g.add_conditional_edges(
        "guardrail",
        route_after_guardrail,
        {"entry_router": "entry_router", "reject": "reject"},
    )

    # reject → END
    g.add_edge("reject", END)

    # entry_router → intent | collect
    g.add_conditional_edges(
        "entry_router",
        entry_router,
        {"intent": "intent", "collect": "collect"},
    )

    # intent → collect | tool | respond | END
    g.add_conditional_edges(
        "intent",
        route_after_intent,
        {"collect": "collect", "tool": "tool", "respond": "respond", END: END},
    )

    # collect → respond | END
    g.add_conditional_edges(
        "collect",
        route_after_collect,
        {"respond": "respond", END: END},
    )

    # tool always feeds into respond
    g.add_edge("tool", "respond")

    # respond → reset | END
    g.add_conditional_edges(
        "respond",
        route_after_respond,
        {"reset": "reset", END: END},
    )

    # reset → END
    g.add_edge("reset", END)

    return g


# Compiled app — import this in main.py
app = build_graph().compile()
