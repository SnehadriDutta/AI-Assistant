import logging
from typing import cast
from tenacity import RetryError

from schemas import AppState, IntentResult
from llm_client import intent_llm
from utils.helpers import with_llm_retry, normalise_slots, LLM_ERROR_RESPONSE

logger = logging.getLogger(__name__)

_INTENT_SYSTEM = """
You are a financial assistant. For each user message:
1. Classify the intent (place_order | add_watchlist | market_query | portfolio_query | general)
2. Extract any slot values already present in the message
3. Build a tool_plan — list of tools needed with their dependencies

Available tools:
- get_prices      : args: symbol          | depends_on: []               | critical: true  | retryable: true
- get_news        : args: symbol          | depends_on: []               | critical: false | retryable: true
- get_portfolio   : args: user_id         | depends_on: []               | critical: true  | retryable: true
- get_historical  : args: symbol, period  | depends_on: []               | critical: true  | retryable: true

Dependency rules:
- portfolio_query that needs per-holding prices → get_portfolio first, then get_prices (depends_on: [get_portfolio])
- symbol performance query → get_historical + get_news in parallel (no depends_on on either)

Valid slot names: symbol, units, order_type, price, sl, tp
Always use lowercase for slot values (e.g. order_type: "limit" not "LIMIT").
""".strip()


def intent_node(state: AppState) -> AppState:
    user_msg = state["messages"][-1]["content"]

    try:
        result = cast(
            IntentResult,
            with_llm_retry(
                intent_llm.invoke,
                [
                    {"role": "system", "content": _INTENT_SYSTEM},
                    {"role": "user",   "content": user_msg},
                ],
            ),
        )
    except RetryError as exc:
        logger.error(f"Intent LLM failed after retries: {exc}")
        return {
            **state,
            "intent": "__llm_error__",
            "messages": state["messages"] + [
                {"role": "assistant", "content": LLM_ERROR_RESPONSE}
            ],
        }

    slots     = normalise_slots({**state["slots"], **result.slots})
    tool_plan = [t.model_dump() for t in result.tool_plan]

    logger.info(f"Intent={result.intent} slots={slots} tool_plan={tool_plan}")

    return {
        **state,
        "intent":           result.intent,
        "slots":            slots,
        "awaiting_confirm": False,
        "tool_plan":        tool_plan,
    }
