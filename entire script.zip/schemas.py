from typing import TypedDict, Optional, Literal, Any
from pydantic import BaseModel, Field


# ── App State ─────────────────────────────────────────────────────────────────

class ToolResult(TypedDict):
    status: Literal["ok", "failed", "cancelled"]
    data:   Any
    error:  Optional[str]   # human-readable; safe to surface in prompts


class ToolCallPlan(TypedDict):
    name:       str
    depends_on: list[str]
    critical:   bool   # if True and fails, abort the entire wave
    retryable:  bool   # if True, retry on transient errors


class AppState(TypedDict):
    messages:          list[dict]
    intent:            Optional[str]
    slots:             dict
    awaiting_confirm:  bool
    tool_plan:         list[ToolCallPlan]
    tool_results:      dict[str, ToolResult]
    user_id:           str
    guardrail_verdict: Optional[str]   # "pass" | "off_domain" | "unsafe"


# ── LLM Output Schemas ────────────────────────────────────────────────────────

class ToolCallPlanSchema(BaseModel):
    name:       str
    depends_on: list[str] = Field(default_factory=list)
    critical:   bool      = True
    retryable:  bool      = True


class IntentResult(BaseModel):
    intent: Literal[
        "place_order",
        "add_watchlist",
        "market_query",
        "portfolio_query",
        "general",
    ]
    slots:     dict                    = Field(default_factory=dict)
    tool_plan: list[ToolCallPlanSchema] = Field(default_factory=list)


class SlotExtractionResult(BaseModel):
    slots: dict = Field(default_factory=dict)


class GuardrailResult(BaseModel):
    verdict: Literal["pass", "off_domain", "unsafe"]
    reason:  str   # internal log only — never shown to user
